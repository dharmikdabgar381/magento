<?php

class Ccc_Practice_Model_Mysql4_Practice extends Ccc_Practice_Model_Resource_Practice
{

}