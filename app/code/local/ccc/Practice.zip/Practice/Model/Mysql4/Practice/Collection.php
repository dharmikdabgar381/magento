<?php

class Ccc_Practice_Model_Mysql4_Practice_Collection extends Ccc_Practice_Model_Resource_Practice_Collection
{

}

?>