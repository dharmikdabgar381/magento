<?php
class Ccc_Practice_Adminhtml_Catalog_ProductController extends Mage_Adminhtml_Controller_Action
{
	public function indexAction()
	{
		// echo "I am in Product Controller";
	}
}

?>