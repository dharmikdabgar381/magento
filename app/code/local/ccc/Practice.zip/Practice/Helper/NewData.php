<?php
class Ccc_Practice_Helper_NewData extends Ccc_Practice_Helper_Data
{
	
	function __construct()
	{
		echo "New Data......";
	}
}