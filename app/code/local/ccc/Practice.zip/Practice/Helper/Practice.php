<?php
/**
 * 
 */
class Ccc_Practice_Helper_Practice extends Mage_Core_Helper_Abstract
{
	
	function __construct()
	{
		// code...
	}
}