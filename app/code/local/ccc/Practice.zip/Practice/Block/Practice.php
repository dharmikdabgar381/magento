<?php
class Ccc_Practice_Block_Practice extends Mage_Core_Block_Template
{
	
	function __construct()
	{
		parent::__construct();
		
	}
}