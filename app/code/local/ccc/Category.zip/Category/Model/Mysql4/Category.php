<?php

class Ccc_Category_Model_Mysql4_Category extends Ccc_Category_Model_Resource_Category
{

}