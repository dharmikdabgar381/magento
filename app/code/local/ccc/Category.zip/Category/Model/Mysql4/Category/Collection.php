<?php

class Ccc_Category_Model_Mysql4_Category_Collection extends Ccc_Category_Model_Resource_Category_Collection
{

}

?>