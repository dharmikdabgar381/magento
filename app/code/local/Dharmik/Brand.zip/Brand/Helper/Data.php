<?php
/**
 * 
 */
class Dharmik_Brand_Helper_Data extends Mage_Core_Helper_Abstract
{
	
	function __construct()
	{
		// code...
	}
}