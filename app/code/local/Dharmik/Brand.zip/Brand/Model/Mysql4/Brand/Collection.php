<?php

class Dharmik_Brand_Model_Mysql4_Brand_Collection extends Dharmik_Brand_Model_Resource_Brand_Collection
{

}

?>