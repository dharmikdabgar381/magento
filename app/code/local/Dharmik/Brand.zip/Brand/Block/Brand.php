<?php
class Dharmik_Brand_Block_Brand extends Mage_Core_Block_Template
{
	
	function __construct()
	{
		parent::__construct();
		
	}
}